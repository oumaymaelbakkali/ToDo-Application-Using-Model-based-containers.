#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}
QString Dialog::Descri() const
  {
      return ui->lineEdit->text();
  }

QString Dialog::Combo() {
    return ui->comboBox->currentText();


}
bool Dialog::finish() {
    if(ui->checkBox->isChecked())
        return 1;
    else
        return 0;


}

QString Dialog::Date() const{
    return ui->dateEdit->text();
}
bool Dialog::CompareDate(){
    QDate Date=QDate::currentDate();
if(ui->dateEdit->text()==Date.toString("dd/MM/yyyy")){
        return 1;

}else
        return 0;
}

