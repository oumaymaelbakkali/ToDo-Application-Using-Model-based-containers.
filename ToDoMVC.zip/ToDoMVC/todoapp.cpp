#include "todoapp.h"
#include "ui_todoapp.h"
#include"dialog.h"
#include<QDateTime>
#include<QList>

ToDoApp::ToDoApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ToDoApp)
{
    ui->setupUi(this);

   // se connecter  a la base de donnée
    connectDatabase();
}

void ToDoApp::addEntry(QString desc,bool finished,QString combo,QString date){
      auto query = new QSqlQuery(db);
      QString insert{"INSERT INTO tasks VALUES('%1', '%2','%3','%4')"};
      if((!query->exec(insert.arg(desc).arg(finished).arg(combo).arg(date))))
        QMessageBox::critical(this,"Error","could not create an entry");

}


ToDoApp::~ToDoApp()
{
    delete ui;
}
void ToDoApp::connectDatabase(){
    //cree une base de donnée qsllite
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\uemf\\OneDrive\\ouma1.sqlite");
    //ouvrir  la base de donne
    if(!db.open())
        QMessageBox::critical(this,"Error","could not open the database");
    //cree la table des taches
    auto query = new QSqlQuery(db);
    QString create{"CREATE table IF  NOT EXISTS tasks (description VARCHAR(80),finished BOOLEAN,Tag VARCHAR(80),Date VARCHAR(80))"};
    if(!query->exec(create))
        QMessageBox::critical(this,"Error","could not create the database");
}


void ToDoApp::on_actionNew_Task_triggered()
{
    Dialog D;
    QDateTime now = QDateTime::currentDateTime();
    auto replay=D.exec();

    if(replay== QDialog::Accepted && D.finish()==0 && D.CompareDate()==1){
        QStringList  tasks{D.Descri(),QString(D.finish()),D.Combo(),D.Date()};
        addEntry(D.Descri(),D.finish(),D.Combo(),D.Date());
                  //cree le model
                  auto model =new QSqlQueryModel;
                  //cree la request du view
                  auto query = QSqlQuery(db);
                  QString view{"SELECT * FROM tasks WHERE Date= '23/01/2022' "};
                   query.exec(view);
                  //associer le model a la requette
                  model->setQuery(query);
                  //assoier le model au view
                  ui->tableView->setModel(model);

    }else if(replay==QDialog::Accepted && D.finish()==0 && D.CompareDate()==0){
        QStringList  tasks2{D.Descri(),QString(D.finish()),D.Combo(),D.Date()};
         addEntry(D.Descri(),D.finish(),D.Combo(),D.Date());
              auto model =new QSqlQueryModel;
              //cree la request du view
              auto query = QSqlQuery(db);
              QString view{"SELECT * FROM tasks WHERE finished= FALSE AND Date!= '23/01/2022' "};
               query.exec(view);
              //associer le model a la requette
              model->setQuery(query);
              //assoier le model au view
              ui->tableView_2->setModel(model);
}else if(replay== QDialog::Accepted && D.finish()==1 && D.CompareDate()==0){
        QStringList  tasks{D.Descri(),QString(D.finish()),D.Combo(),D.Date()};
         addEntry(D.Descri(),D.finish(),D.Combo(),D.Date());
              auto model =new QSqlQueryModel;
              //cree la request du view
              auto query = QSqlQuery(db);
              QString view{"SELECT * FROM tasks WHERE finished= TRUE"};
               query.exec(view);
              //associer le model a la requette
              model->setQuery(query);
              //assoier le model au view
              ui->tableView_3->setModel(model);
}






}

void ToDoApp::on_actionPlaning_Task_triggered()
{   ui->tableView_2->show();
    ui->tableView->hide();
    ui->tableView_3->hide();

}

void ToDoApp::on_actionFinished_Task_triggered()
{
    ui->tableView_3->show();
    ui->tableView->hide();
    ui->tableView_2->hide();

}

void ToDoApp::on_actionAbout_Qt_triggered()
{
       QMessageBox::aboutQt(this,"AboutQT");
}

void ToDoApp::on_actionQuit_triggered()
{
    this->close();
}
