#include <QMainWindow>
#include<QSqlDatabase>
#include<QSqlQueryModel>
#include<QMessageBox>
#include<QSqlQuery>
#include<QSqlDatabase>

QT_BEGIN_NAMESPACE
namespace Ui { class ToDoApp; }
QT_END_NAMESPACE

class ToDoApp : public QMainWindow
{
    Q_OBJECT

public:
    ToDoApp(QWidget *parent = nullptr);
    ~ToDoApp();

protected:
    void connectDatabase();

    void addEntry(QString desc,bool finished,QString combo,QString date);

private slots:
    void on_actionNew_Task_triggered();

    void on_actionPlaning_Task_triggered();

    void on_actionFinished_Task_triggered();

    void on_actionAbout_Qt_triggered();

    void on_actionQuit_triggered();

private:
    Ui::ToDoApp *ui;
      QSqlDatabase db;
};

